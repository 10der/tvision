﻿namespace TurboVision
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Security;
    using System.Text;

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct CHAR_INFO
    {
        public char WideChar;
        public ushort Attributes;

        public CHAR_INFO(char chr, ConsoleColor foreColor, ConsoleColor backColor)
        {
            WideChar = chr;
            Attributes = (ushort)((uint)foreColor | ((uint)backColor << 4));
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct SMALL_RECT
    {
        public short Left;
        public short Top;
        public short Right;
        public short Bottom;

        public SMALL_RECT(int left, int top, int width, int height)
        {
            Left = (short)left;
            Top = (short)top;
            Right = (short)(left + width);
            Bottom = (short)(top + height);
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct COORD
    {
        public short X;
        public short Y;

        public COORD(int x, int y)
        {
            this.X = (short)x;
            this.Y = (short)y;
        }
    }

  //  [SuppressUnmanagedCodeSecurity, SecurityCritical]
    internal static class ConsoleDriver
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        public static extern bool WriteConsoleOutput(IntPtr hConsole, CHAR_INFO[] lpBuffer, COORD dwBufferSize, COORD dwBufferCoord, ref SMALL_RECT lpWriteRegion);
    }
}
